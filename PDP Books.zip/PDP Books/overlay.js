/**
 * Show an overlay (modal/layer) on click of the matched element(s).
 * 
 * There are 3 ways to instantiate an overlay using this plugin:
 * 
 * 1. Use an anchor element with a class of `modal` or `layer` and a properly formatted `href` attribute. The plugin automatically looks for these classes.
 * 
 * 2. Calling the plugin on an element or elements and passing an `options` object.
 * 
 * 3. Using the `$.overlay.load()` method and passing in an `options` object. These cases are few but this method can come in handy when you need to open an overlay without a user clicking a target element or from another function's callback handler.
 * 
 * 
 * @example
 * <a class="modal" href="url/to/the/content-file.php">Some Text</a>
 * @title Instantiation Method #1
 * @syntax html
 * @desc Instantiation using an anchor's `href` attribute to configure options. For the fully default implementation, all that is needed is the location of the content file in the `href`.
 * The anchor's `class` can determined whether the overlay is a modal (background blocking curtain) or layer (no curtain). For modals use class="modal" and for layers, class="layer".
 * 
 * @example
 * $('.some-class').overlay({
 *      content: 'url/to/the/content-file.php',
 * });
 * @title Instantiation Method #2
 * @syntax javascript
 * @desc Instantiation using an options object. For the fully default implementation (modal by default), all that is needed is the location of the `content` file.
 * 
 * 
 * @example
 * $.overlay.load({
 *      content: 'url/to/the/content-file.php'
 * });
 * @title Instantiation Method #3
 * @syntax javascript
 * @desc Initiation an overlay using the `$.overlay.load()` method and an options object. For the fully default implementation (modal by default), all that is needed is the location of the `content` file. This loads the overlay as soon as the code is evaluated. You should wrap this in a callback to an event.
 * 
 * 
 * @example
 * <a class="layer" href="url/to/the/content-file.php?overlayId=myLayer&position=#primary&closeLink=false&validation=false">Some Text</a>
 * @title Instantiate a layer using the html-only method with more options. 
 * @syntax html
 * @desc The options will submitted via a query string in the anchor's `href` attribute:
 * - ID of `#myLayer`.
 * - positioned relative to the target's `#primary` parent element
 * - content url via `href`'s standard url
 * - No close link
 * - No form validation
 * 
 * 
 * @example
 * $('#some-button').bind('click', function() {
 *     var target = $(e.currentTarget);
 *     $.overlay.preventDuplicate(target);
 *     // some code that eventually calls $.overlay.load();
 * });
 * @syntax javascript
 * @title Use of `$.overlay.preventDuplicate()` to prevent multiple clicks on an overlay target
 * @desc Users can accidentally click more than once on an overlay button or link and receive a javascript exception that causes them to navigate to a raw html page. The Overlay framework handles this when the element uses the auto instantiation methods. But there are cases where we need to open an overlay programatically using `$.overlay.load()` (adding an item to cart for example). In these cases `$.overlay.preventDuplicate();` checks to see if the `target` param has the overlay active class. If so, an exception is thrown. The `target` param can be any DOM node, css selector or jQuery object. `target` must refer to the element that triggers the overlay.
 * 
 * 
 * 
 * @example
 * $('body').delegate('#some-overlay-id', 'overlay-before-show', function(event) {
 *     var overlay = this;
 *     // Do something...
 * });
 * @title Overlay Custom Events: `overlay-before-show`
 * @syntax javascript
 * @desc Fires on the overlay element stored in the `$.overlay.currentOverlay` property once it has been appended to the `body` element.
 * External scripts that need to bind a `submit` event to the overlay's form elements to overide the default `submit` event should use this event.
 * 
 * 
 * @example
 * $('body').delegate('#some-overlay-id', 'overlay-show', function(event) {
 *     var overlay = this;
 *     // Do something...
 * });
 * @title Overlay Custom Events: `overlay-show`
 * @syntax javascript
 * @desc Fires on the overlay element stored in the `$.overlay.currentOverlay` property once it has been animated into view or its content have been updated via ajax.
 * 
 * 
 * @example
 * $('body').delegate('#some-overlay-id', 'overlay-before-hide', function(event) {
 *     var overlay = this;
 *     // Do something...
 * });
 * @title Overlay Custom Events: `overlay-before-hide`
 * @syntax javascript
 * @desc Fires on the overlay element stored in the `$.overlay.currentOverlay` property just before it closes.
 * 
 * 
 * @example
 * $('body').bind('overlay-hide', function(event, overlayId) {
 *     if(overlayId === '#some-id') {
 *         // Do something...
 *     }
 * });
 * @title Overlay Custom Events: `overlay-hide`
 * @syntax javascript
 * @desc Fires on the `body` element once the `$.overlay.currentOverlay` property has been set to `false`.
 * The event handler receives the `id` of the removed overlay as a String (with the `#` character).
 * 
 * 
 * @example
 * $('body').delegate('#some-overlay-id', 'overlay-before-show', function(event) {
 *     $(this).find('form').bind('pausesubmit.overlay', function(event) {
 *         var form = $(this);
 *         // Do something...
 *         form.trigger('resumesubmit.overlay');
 *  	});
 * });
 * @title Overlay Custom Events: `pausesubmit.overlay`
 * @syntax javascript
 * @desc If this event is set on the overlay's `form` element, its handler will be called before the `submit` event occurs. 
 * This is useful if an external script needs to have access to the `form` on `submit` but does not need to override the default `submit` event.
 * Notice: Once your handler has finished its execution it must trigger the `resumesubmit.overlay` event on the form. This signals the default `submit` process to resume. This is needed in case the handler needs to wait for an ajax request or animation to finish.
 * External scripts need to use this in combination with the `overlay-before-show` event.
 * 
 * 
 * @example
 * // On start of a event/update
 * $.overlay.currentOverlay.trigger('overlay-loading');
 * 
 * // After the event/update is complete
 * $.overlay.currentOverlay.trigger('overlay-show');
 * @title Overlay Custom Events: `overlay-loading`
 * @syntax javascript
 * @desc Activate a loading animation and blocking curtain. By default, this is triggered during any automatic `AJAX` update inside an overlay. For any custom events/updates that the Overlay Framework does not track, use this event to inform the user that a request is happening and protect the overlay content from mouse interaction.
 * 
 * 
 * @example
 * $.overlay.currentOverlay.trigger('close.overlay', [true]);
 * @title Overlay Custom Events: `close.overlay`
 * @syntax javascript
 * @desc Force an overlay to close. Triggering this event runs the same routine as when a user clicks a close/cancel button/link. Note: An array with the first index value set to `true` must be passed as the second argument to make sure the original `target` regains focus. This is not needed if in an overlay flow.
 * 
 * 
 * @example
 * <a href="#close" class="close" title="Close this overlay to return to the previous section">Close</a>
 * @title Providing Alternate User Actions to Close an Overlay
 * @syntax html
 * @desc To give a user an alternate method to close an overlay, simply apply an `id` or `class` of `close` to a clickable element.
 * 
 * 
 * @example
 * $.overlay.load({
 * 	  content: 'url/to/the/content-file.php',
 * 	  intercept: function(response) {
 * 	      if(response.errorFields === '') {
 * 	          // No errors!
 * 	          return response;
 * 	      } else {
 * 	          return false;
 * 	      }
 * 	  }
 * });
 * @title Use of `intercept` to Validate Response Object
 * @syntax javascript
 * @desc `intercept` is a pre-callback that allows you to validate the response object before it is sent to the overlay. Use this to validate data returned from server to determine whether overlay should be shown. The response object is passed as the only argument and must be `json`. `return false` in the function to cancel the overlay, `return` the `response` to show the overlay.
 * Notice: The response `json` should have the following properties: `errors`, and `overlayOptions`. If the errors need to be injected into the form, the prop should contain a properly formatted object for the validator to use: `{'input-name-attr': 'The error message'}`. The `overlayOptions` prop should contain an object with at least the `html` prop that holds the content to be displayed in the overlay should there be no errors. If other keys in the `overlayOptions` object match any overlay options (`overlayType: 'modal'` for example), they will be used to update the overlay's options before it is shown.
 * 
 * 
 * @example 
 * // Check to see if a specific overlay is open
 * if($.overlay.activeOverlay) {
 *     var overlay = $.overlay.currentOverlay; // jQuery object
 *     if(overlay.data('options').overlayId === 'some-id') {
 * 			overlay.addClass('some-new-class');
 *         // Do something...
 *     }
 * }
 * @title Use of `$.overlay.activeOverlay` and `$.overlay.currentOverlay`
 * @syntax javascript
 * @desc `$.overlay.activeOverlay` is a boolean for testing if an overlay is active. The `$.overlay.currentOverlay` property holds the currently open overlay (a jQuery object). The options for this overlay are attached using `data('options')`. `$.overlay.currentOverlay` is set to `false` if an overlay is not active.
 * 
 * 
 * @example
 * <!-- Use an <h1> to title an overlay -->
 * <h1>The Title of the Overlay</h1>
 * @title Accessibility: Semantic HTML
 * @syntax html
 * @desc All overlay content must conform to standard semantic HTML guidelines. For example, a heading element `<h*>` must be used for all overlay titles.
 * The focus is returned to the target upon closing the overlays.
 * Any element can be used as long as it contains `class="module-title"` and `tabindex="-1"`.
 * A heading element `<h*>` is suggested to retain semantics.
 * If none exist, the main content body is focused instead.
 * 
 * 
 * @example
 * $.overlay.load({
 *     target: '#some-id',
 *     content: 'url/to/the/content-file.php'
 * });
 * @title Accessibility: Refocus Triggering Target to Maintain Context
 * @syntax javascript
 * @desc AT (assistive technologies) should always be placed back in the same context after closing an overlay. Losing context in a complex page means having to re-naviagate through all previous content for every asyncronous action. This is not very friendly. The Overlay Framework takes great measures to make this automatic. But, there are instances where the `$.overlay.load()` method needs to be used to provide developer flexibility. To make sure the original context always regains focus, you must define a `target` element in the `options` object. This element must either be natively focusable or contain the attribute/value `tabindex="-1"`.
 * 
 * 
 * @example 
 * <a class="async" href="url/to/the/content-file.php">Asynchronous Link</a>
 * @title Asynchronous Links within Overlay Content
 * @syntax html
 * @desc For overlays that require its contents to be updated via ajax when an `anchor` is clicked, add `class="async"` to the `anchor` and point the `href` attribute to your content file.
 * 
 * 
 * @example 
 * <a class="modal" href="url/to/the/content-file.php">Some Text</a>
 * @title Overlay creation within Overlay Content
 * @syntax html
 * @desc For overlays that require its content to contain links to new overlays, add `class="modal"` or `class="layer"` to the `anchor` and configure the `href` consistent with the type of overlay needed.
 * 
 * 
 * @example
 * <!-- Expected Markup -->
 * <button class="button sync" value="1" name="some-name" type="submit" title="Some Text"><span class="buttonText">Some Text</span></button>
 * 
 * // Using acme( 'button', options ) is required instead of simply writing the generated markup
 * <?php
 *     acme( 'button', array(
 *         'text' => 'Some Text',
 *         'title' => 'Some Text',
 *         'name' => 'some-name',
 *         'value' => true,
 *         'class' => 'sync'
 *    ));
 * ?>
 * @title Synchronous Form Submits
 * @syntax html
 * @desc For forms that need synchronous submits (no ajax), add `class="sync"` to the submit `button`.
 * 
 * 
 * @example
 * $(document).delegate('{#some-overlay-id}', 'overlay-before-show', function(e) {
 *     var overlay = $.overlay.currentOverlay;
 *     var form    = overlay.find('{#some-form-id}');
 *     form.bind('validated', function(e) {
 *         // e.valid - Boolean - Did the form validate?
 *         if(e.valid) {
 *             console.log('Successful validation Ominture code here');
 *         } else {
 *             console.log('Non-Successful validation Ominture code here');
 *         }
 *     });
 * });
 * @title Adding Omniture to a Form Controlled by the Validation and Overlay Frameworks
 * @syntax javascript
 * @desc When Omniture code needs to be added to forms controlled by the Validation framework and contained within an overlay, the following pattern should be used. The Validation framework fires a `validated` event when the form has been validated. The `event` object contains a `valid` property (`Boolean`) for testing if the clientside validation was successful.
 * 
 * 
 * @param Object options An options object.
 * @option String overlayId Identifier attribute to be added to the overlay. Default is `overlay`.
 * @option String overlayType `modal` or `layer`. `modal`s display a blocking curtain. `layer`s do not. Default is `modal`.
 * @option String mode Currently, the only option for this is `force`. This produces a dark curtain and no close link. The user is forced to make a choice in the overlay. Default is `false`.
 * @option String template What template wrapper to use. The choices are: `xsmall`, `small`, `community`, `medium`, `large`, `xlarge`. Any css class will work as long as there is corresponding css to support the overlay. The default is `default`.
 * @option String content URL to the content file. Default is `false`.
 * @option Mixed data Data that gets sent to the server when the content is requested. The default is `null`.
 * @option Boolean closeLink Show a close link at top of overlay. Default is `true`. [For modals only: If the `mode` option is set to `force` than this option is ignored.]
 * @option String validate If a `form` is present, should it be validated? Default is `true`. Requires an accompanying validation object in the html.
 * @option String position For layers only. Options are: `targetAbove`, the bottom of the overlay shows at the top-right of the target; `targetCenter`, the overlay shows center-right of the target; `targetBelow`, the top of the overlay shows at the top-right of the target; css selector; dom object; jQuery object. The overlay shows top=0 and left=0 of the first matched element. When a css selector, dom object or jQuery object is supplied, the framework will first look for the one closest match (using jQuery's `.closet()`). If nothing was found, it find the first one on the page. Default is `body`.
 * @option Number x [For `layer`s only]. Position the overlay x value absolutely relative to the `body` element. Default is `0`.
 * @option Number y [For `layer`s only]. Position the overlay y value absolutely relative to the `body` element. Default is `0`.
 * @option Number width Override the template's width.
 * @option Number height Override the template's height.
 * @option Function intercept A pre-callback to validate the response object before it is sent to the overlay. Use this to validate data returned from server to determine whether overlay should be shown. The response object is passed as the only argument and must be `json`. `return false` in the function to cancel the overlay, `return` the `response` to show the overlay. Default is `false`.
 * @option Mixed target [Only accepted when using `$.overlay.load()`] Any DOM node, css selector or jQuery object (must be singular, i.e. the selector resolves to only one element in the page, and `id` is recommended). Default is `false`.
 * @option String contentOverride [Only accepted when using `$.overlay.load()`] The markup to be inserted into the overlay. The `content` options is ignored if `contentOverride` is set. Default is `false`.
 * @option String passForm Accepts a jQuery selector string (example: `#myFormID`), serializes the provided form if one is found, and passes the form data to the server when the content is requested. [NOTE - overwrites the data option]  Default is `false`.
 *
 * 
 * @name overlay
 * @type jQuery
 * @author Ryan Fitzer
 */

/*
	Nice-to-haves
	-------------
	- Run preloader between flows
	- Create a tabbing key check to make sure a keyboard user doesn't accidentally tab out of the overlay
	- Figure out a good pattern for destroying the instance (if needed) via 'destroy'. $.data( this, 'overlay', new overlay( options, this ) ); and then self.element.removeData('overlay').
	- IN-PROGRESS -> Allow for a string/jQuery-object/dom-node to be passed instead of options and used as the 'contentOverride'. $().overlay(string|jQuery-object|dom-node); Test (obj instanceof jQuery).
	- $.overlay.setDefaults();
	- Rethink events: pauseshow, beforeshow, show, pausehide, beforehide, hide. 
	- Option to extend overlayType with function for showing new type.
	- Set up curtain click-to-close event as an option.
	- Unit testing
*/

;(function($) {
	
	var win = $(window),
		doc = $(document),
		defaults = {
			overlayId: 'overlay',
			overlayType: 'modal',
			mode: false,
			template: 'default',
			content: false,
			image: false,
			data: null,
			closeLink: true,
			validate: true,
			position: 'body',
			x: false,
			y: false,
			width: false,
			height: false,
			intercept: false,
			passForm: false,
            curtainClose: false, /* POC04 */
			componentPop: false,
            gMap: { //For Gomez, key => overlay ID, Value => value to be set in Gomez setInterval when overlay opens up
                QuickView: 'Quick Info',
                addtocart: 'Add to Cart'
            },
            gMapVal: null
		},
		defaultsLoad = $.extend({
			target: false,
			contentOverride: false
		}, defaults),
		templateMarkup = '<div class="overlay {templateClass}"><div class="content" tabindex="-1"></div><div id="overlay-loading-curtain"></div></div>',
		preloaderMarkup = '<div id="overlay-loader"></div>',
		curtainMarkup = '<div id="overlay-curtain"></div>',
		closeMarkup = '<a id="close" href="#close" class="icon-sprite close"><span class="screen-reader-only">Close</span></a>',
		arrowMarkup = '<div id="arrow-icon"></div>';
	
	$.fn.overlay = function(options) {
		doc.delegate(this.selector, 'click.overlay', {options: options}, function(e) {
			e.preventDefault();
			new $.overlay(
				this,
				$.extend( {}, defaults, e.data.options instanceof jQuery ? {contentOverride: e.data.options} : e.data.options || {} ),
				false
			);
		});
		return this;
	}
	
	$.overlay = function(element, options, load) {
		this.isLoad	= load ? load : false;
		this.body = $('body');
		this.options = options;
		this.element =
			(element) ? $(element)
			: (this.options.target instanceof jQuery) ? this.options.target.eq(0)
			: this.options.target && $(this.options.target).eq(0);
		this.options.target = this.element.length ? this.element : false;
		this.setup();
	};	
	
	$.overlay.load = function(options) {
		options = $.extend({}, defaultsLoad, options || {});
		new $.overlay(false, options, true);
	};
	
	$.overlay.exception = function(exception, cleanup, log) {
		log =
			typeof exception === 'boolean' ? exception
			: typeof cleanup === 'boolean' ? cleanup
			: typeof log === 'boolean' ? log
			: true;
		cleanup =
			$.isFunction(exception) ? exception
			: $.isFunction(cleanup) ? cleanup
			: $.isFunction(log) ? log
			: false;
		exception =
			(typeof exception === 'string') ? exception
			: 'Stopped due to an undefined exception.';
		var message = exception;
		
		try {
			log && console.log('Overlay.js exception, ' + exception);
			cleanup && cleanup();
		} catch(e) {
			window.console && console.log(e);
		}
		
		window.onerror = function(e) {
			return true;
		}
		setTimeout(function() {
			window.onerror = null;
		}, 100);
		
		throw message;	
	}
		
	$.overlay.preventDuplicate = function(element, showError) {
		showError = typeof showError === 'boolean' ? showError : true;
		var target =
			(element) && (element instanceof jQuery) && element.length ? element.eq(0)
			: (element) && (element = $(element)) && element.length ? element
			: false;
		var cleanup = function() {
			($.overlay.currentOverlay.find('.module-title:first').length)
			? $.overlay.currentOverlay.find('.module-title:first').focus()
			: $.overlay.currentOverlay.find('.content').focus();
		}
		
		if(!target) $.overlay.exception('The "target" supplied to "$.overlay.preventDuplicate" was not valid.', showError);
		if(target.hasClass('overlay-open')) $.overlay.exception('"$.overlay.preventDuplicate" found this overlay already open.', cleanup, showError);

	}
		
	$.overlay.prototype = {
		
		inited: false,
		
		setup: function() {

			var self 	    = this,
				preloader   = self.body.find('#overlay-loader'),
				curtain     = self.body.find('#overlay-curtain');
			
			if(!curtain.length) {
				self.curtain = $(curtainMarkup).appendTo(self.body);
			} else {
				self.curtain = curtain;
			}

			if(!preloader.length) {
				self.loadAnimation = $(preloaderMarkup).appendTo(self.body);
			} else {
				self.loadAnimation = preloader;
			}
			
			self.element && $.overlay.preventDuplicate(self.element, false);
			self.consolidateOptions();
			self.init();
						
		},
		
		init: function() {
			
			var self = this,
			ename = "click.closeOverlay";
			
			if(self.element) {
			    				
				// Add an easy way to check the target's overlay options
				self.element.data('overlay', {});
				for(option in self.options) self.element.data('overlay')[option] = self.options[option];
				
				// Disallow the target to re-init the open modal
				if(self.element.hasClass('overlay-open')) {
					return false;
				} else {    
                    if(!$.overlay.originalTarget) self.element.addClass('overlay-open state-disabled');
				};
			};
			
			self.body.bind('loading.overlay', function(e) {
				self.body.addClass('overlay-loading').unbind('loading.overlay');
			}).bind('loaded.overlay', function(e) {
				self.preloader('hide');
				self.body.removeClass('overlay-loading').unbind('loaded.overlay');
			});
			
			ename = (Target.support.isTouch) ? "click.closeOverlay touchend" : ename;
			self.body.bind(ename, function(e) {
				if (!$.overlay.activeOverlay) {
					return; //no visible overlay to close
				}
				if (!$.overlay.currentOverlay) {
					return; //no current overlay to close
				}
				//have active overlay
				//the parents selector may need to be changed based on what the overlay classname will always
				if ($(e.target).parents('.overlay, .modal, .datepicker').length) {
					return; //the click target is in the overlay, do not close
				} else {
					if( !$(e.target).is('.prevFrame, .nextFrame,  #zoompicker') ) { //.is method impact perf, need to come up with alter solution
						$.overlay.currentOverlay.trigger('close.overlay',[true]);
						return false;
					}
				}

			});
			
			
			
			// If there is an overlay showing, we need to close it and then set in motion our new overlay.
			// Triggering a custom event on the body solves the case so functions can run in order.
			if($.overlay.activeOverlay) {
				self.body.bind('overlay-removed', function(e) {
					self.getContent();
				});
				$.overlay.overlayFlow = true;
				$.overlay.currentOverlay.trigger('close.overlay');
			} else {
			    $.overlay.overlayFlow = false;
			    $.overlay.originalTarget = self.element;
				self.preloader('show');
				self.getContent();
			};
		},

		getContent: function() {

			var self 				= this;
			var args				= arguments;
			var url					= (args.length) ? args[0] : self.options.content;
			var intercept			= self.inited === false && $.isFunction(self.options.intercept);
			var dataType			= self.options.dataType;
			self.currentTemplate	= 
				($.overlay.activeOverlay && !self.options.contentOverride)
				? $.overlay.currentOverlay
				: $(templateMarkup.replace('{templateClass}', self.options.template));
			var content				= self.currentTemplate.find('.content');
			var forms				= self.currentTemplate.find('form');
			var data				= 
				(self.options.data !== null && !self.inited) 
				? self.options.data
				: self.inited && forms.length
				? forms.serialize()
				: null;
				
		
			/* Check for "/qi/" in the url and if it exist assign self.options.overlayId = "QuickView" */ 
			/* Sample Url: "/qi/Product Name/-/A-11359182" */
			try{
				if( typeof url != 'undefined' && url != false && url.search(/^\/qi\//i) == 0 ){
					self.options.overlayId = "QuickView"; 
					self.options.backLog = "true"; //send the response object
				}
			}catch(err){}
			
			if(!self.inited) {
				self.body.trigger('loading.overlay');
			}
			
			// If a form is passed with the passForm option, overwrite the data object with the contents of the form
			if(self.options.passForm) {
				data = $(self.options.passForm).serialize();
			};
			if( self.options.overlayId ) {
            	   
            	   	if( self.options.overlayId === "QuickView" ) {
						self.options.overlayType = 'modal';
					}
            	   	if( typeof gomez !=="undefined" ) {
            	   		if( self.options.gMapVal ) {  // scenario: for passing gomez attributes via url
                            self.options.gMap[self.options.overlayId] = self.options.gMapVal;
                        }
                        try {
                        	if(typeof self.options.gMap[self.options.overlayId] !== "undefined") {
                                gomez.startInterval(self.options.gMap[self.options.overlayId]);
                                gomez['pgId'] = self.options.gMap[self.options.overlayId];
                        	}
                        } catch(e) { }
            	   	}
               }
			
			if (self.options.contentOverride) {

				self.show(self.options.contentOverride);
				self.inited = true;
				
			}
			else if (self.options.image) {
			    
                var attrs = self.options.image.split('|'),
                    src = attrs[0],
                    query = attrs[1] ? '?' + attrs[1].replace('*', '&') : '',
                    alt = attrs[2] || '',
                    width = attrs[3] || '',
                    height = attrs[4] || '',
                    img = new Image();
                
			    img.src = src + query;
			    img.alt = alt;
			    img.width = width;
			    img.height = height;
                
                self.show(img);
				self.inited = true;
				
			}
			else {
				var selTxt ='QuickInfoView?';
				
				try{
					if ( url !='' && url.indexOf(selTxt) > -1 ){
						url = url.replace(selTxt,'qi?');
						var domainName =url.split('?')[0],
							sURLVariables = url.split('?')[1].split('&'),
							newfixURL = url.split("?")[1],
							partNumber = '';
							for (var i = 0; i < sURLVariables.length; i++){							
								 var sParameterName = sURLVariables[i].split('=');
								 if (sParameterName[0] == 'partNumber'){    
									 partNumber = sParameterName[1];
								 }
							 }
							if(partNumber != "" && partNumber !="undefined"){
								url = domainName+'/-/A-'+partNumber+"?"+newfixURL;;
							}
						
					} else if ($("body").hasClass('tsa') && url.indexOf('/p/')) {
						url = url.replace("/p/", "/qi/");
					}
				}catch(e){}
				$.ajax({
					url: url,
					data: data,
					dataType: intercept ? 'json' : 'html',
					cache: false,
					type: 'POST',
					curtain: false,
					success: function(response, status, xhr) {
						
						var data = response,
						    redirect = xhr.getResponseHeader('X-Redirect');
						
						if(redirect && redirect !== '' ) {
						    return window.location.replace(redirect);
						}
					    
						if(intercept) {
							if(data = self.options.intercept.call(self, response)) {
								if(data.overlayOptions) {
									for(option in data.overlayOptions) {
										self.options[option] && (self.options[option] = data.overlayOptions[option]);
									}
								}
								if(data.overlayOptions.html)
									self.show(data.overlayOptions.html);
								else $.overlay.exception("No html was returned via the object's overlayOptions.html property");
							}
						} else {
							self.show(response);
						}
						self.inited = true;
					},
					error: function(XMLHttpRequest, textStatus, errorThrown) {
						fromQi=false;
						if(XMLHttpRequest.status === 404 ) {
							if(XMLHttpRequest.responseText) {
								self.show(XMLHttpRequest.responseText);
							} else {
								overlay.attr('aria-busy', 'false');
								overlay.removeClass('loading');
							}
						}
						var message = "Request failed: " + self.options.content;
						window.console && console.log(message);
					}
				});
				
			}
	
		},
		
		show: function(response) {
			
			var self = this;
			var overlay, content;
			
			// Reposition or show overlay
			if($.overlay.activeOverlay) {
				
				overlay = $.overlay.currentOverlay;
				
                if($.overlay.currentOverlay.redirect) {
                    self.body.bind('overlay-removed', function(e) {
                        window.location.href = $.overlay.currentOverlay.redirect;
                    });
                    return overlay.trigger('close.overlay');
                }
				
				overlay.find('.content').html(response);
				overlay.trigger('overlay-before-show');
				alert('here');
				self.processContent();
				overlay.trigger('reposition.overlay');
				overlay.trigger('overlay-show');
				return;
			}
			
			var winWidth	= win.width();
			var winHeight	= win.height();
			var curatinBg	= '#000';
			var layer		= (self.options.overlayType === 'layer');
			var modal		= (self.options.overlayType === 'modal');
			var css			= {};
			css.left		= '-9999em';
 			self.options.width ? css.width = self.options.width + 'px': null;
 			self.options.height ? css.height = self.options.height + 'px': null;
			var showOverlay	= function() {
				
				var pos = self.position();
				if(modal) {
										
					win.bind('resize.overlay', function() {
						self.curtain.width(win.width());
						self.curtain.height(win.height());
					});
					
					if (Target.support.isTouch) {
						winWidth	=  window.innerWidth;
						winHeight	=  window.innerHeight;
					}
					winHeight = ($.browser.msie && parseInt($.browser.version) >= 8) ? winHeight+20 : winHeight;
					self.curtain.css({
						'width': winWidth,
						'height': winHeight,
						'opacity': .30,
						'background': curatinBg
					});

					self.curtain.stop().fadeIn('fast', function() {
						self.curtain.addClass('curtain-open');
						overlay.css({
							top: pos.y,
							left: pos.x,
							width: '874px'
						});
						overlay.addClass('modal');
						overlay.fadeIn(500, function() {
						    overlay.trigger('overlay-show');
            				self.body.trigger('loaded.overlay');
						});
					});
				}
				else {
					// Setup drag functionality
					if($.ui.draggable) {
						overlay.prepend('<div class="drag-handle"/>');
						overlay.draggable({
							handle: '.drag-handle',
							containment: 'document',
							start: function(event, ui) {
								overlay.data('reposition', false);
							}
						});
					}

					overlay.css({
						top: pos.y,
						left: pos.x,
						width: '874px'
					});
					overlay.addClass('layer');
					overlay.fadeIn(500, function() {
					    overlay.trigger('overlay-show');
        				self.body.trigger('loaded.overlay');
					});
				}

			}
						
			self.loadingCurtainMarkup = self.currentTemplate.find('#overlay-loading-curtain');
			self.currentTemplate.attr('id', self.options.overlayId);
			self.currentTemplate.css(css);
			self.body.append(self.currentTemplate);
			
			// Assign the overlay over to the global namespace as soon as it's available in the DOM
			overlay = $.overlay.currentOverlay = self.currentTemplate;
			delete self.currentTemplate;
			$.overlay.activeOverlay = true;
			
			// Add an easy way to check the current overlay's options
			// overlay.data('options', {});
			// for(option in self.options) overlay.data('options')[option] = self.options[option];
			overlay.data('options', self.options);
			
			// Insert the returned markup
			contentArea = overlay.find('.content')
			contentArea.html(response);
						
			overlay.bind('overlay-loading', function(event) {

                overlay.attr('aria-busy', 'true');
				overlay.addClass('loading');
				
				self.loadingCurtainMarkup.css({
					opacity: .6,
					'background-color': '#fff',
					width: overlay.width(),
					height: overlay.height()
				});

			});
			
			overlay.bind('overlay-show', function(event) {

                overlay.attr('aria-busy', 'false');
				overlay.removeClass('loading');
				
				if(overlay.isSecure) return;
				
				// Setup Esc key to hide modal
				overlay.unbind('keydown.overlay').bind('keydown.overlay', function(event) {
					var key = event.keyCode;
					if(self.options.mode === 'force' || !self.options.closeLink) return;
					if(key === 27) {
						overlay.trigger('close.overlay', [true]);
					}
				});
				
				if( overlay.find('.module-title').length ) {
				    self.shiftFocus(overlay.find('.module-title').get(0));
				} else {
				    self.shiftFocus(overlay.find('.content').get(0));
				}
				
			});
			
			/* 
			// Looking to find a way to keep one from tabbing out
			// of an overlay since it is usually the last element
			// in the DOM.
			overlay.bind('keypress', function(event) {
				console.log(event);
				if (event.keyCode === 9) {
					console.log('currentTarget', $(event.currentTarget));
					console.log('child', $(event.currentTarget).find(event.target));
					var parent = $(event.target).parent();
					console.log('target', $(event.target));
					if (parent.is('.overlay') && !$(event.target).is('.content')) {
						console.log('run');
						overlay.find('.content').focus();
						return false;
					}
				}
			});
			*/
			
			overlay.bind('close.overlay', function(e, shiftFocus) {
				self.remove(shiftFocus);
			});
			
			overlay.bind('reposition.overlay', function(event) {
				if(overlay.data('reposition') !== false) {
					var pos = self.position();
					overlay.css({
						top: pos.y,
						left: pos.x,
						width: '874px'
					});
				}
			});
			
			// In-progress
			overlay.bind('retemplate.overlay', function(event, overlayId, template, ssl) {
								
				var type = overlay.hasClass('layer') ? 'overlay layer ' : 'overlay modal ';
				overlayId = overlayId ? overlayId : overlay.attr('id');
				
				overlay.attr({
					'id': overlayId,
					'class': type + template
				});
			});
			
			if(overlay.isSecure) {
				overlay.bind('loaded-ssl', function() {
					overlay.trigger('overlay-before-show');
					showOverlay();
				});
			}
			else {
				overlay.trigger('overlay-before-show');
				self.processContent();
				showOverlay();
			}

		},
		
		shiftFocus: function(element) {
		    
		    var el = $(element);


            // To help Assistive Technologies recognize the focus change,
            // the focus change should happen inside a window timeout

            setTimeout(function () {
				el.attr('tabindex', -1);
                element.focus();
                $(document).trigger('updateBuffer.framework');
                if(element === $.overlay.originalTarget) $.overlay.originalTarget = false;
				el.removeAttr('tabindex');
            }, 0);
		    
		},
		
		remove: function(shiftFocus) {
			
			$.overlay.overlayFlow = shiftFocus ? false : true;
			
			if($.overlay.activeOverlay) {
				
				var self, body, layer, modal, currentOverlay;
				
				$.overlay.activeOverlay = false;
				
				self	= this;
				body	= self.body;
				layer	= (self.options.overlayType === 'layer');
				modal	= (self.options.overlayType === 'modal');
				currentOverlay	= $.overlay.currentOverlay.data('options').overlayId;

				$.overlay.currentOverlay.trigger('overlay-before-hide');
				
				if ($.browser.msie && $.browser.version < 8){
					self.curtain.css({
						height: 0,
						width: 0,
						'visibility': 'visible',
						'display': 'block'
					}).removeClass('curtain-open');
					
					try {
						
						$.hideCurtain();
						if( currentOverlay && typeof currentOverlay !== "undefined") {
							currentOverlay = $("#"+currentOverlay);
							if(typeof currentOverlay !== "undefined") {
								currentOverlay.remove();
							}
														
						}
							
					} catch(e) {
							
					}
					//$.overlay.currentOverlay.remove();
					$.overlay.currentOverlay = false;
					body.trigger('overlay-hide', ['#' + self.options.overlayId]);
					body.trigger('overlay-removed').unbind('overlay-removed');
				}
				
				else {
					
					$.overlay.currentOverlay.fadeOut('fast', function() {
						if(self.curtain.hasClass('curtain-open')) {
							self.curtain.fadeOut('fast', function() {
								self.curtain.css({
									height: 0,
									width: 0,
									'visibility': 'visible',
									'display': 'block'
								}).removeClass('curtain-open');
							});
	
							win.unbind('resize.overlay');
						}
						
						try {
						
							$.hideCurtain();
							if( currentOverlay && typeof currentOverlay !== "undefined") {
								currentOverlay = $("#"+currentOverlay);
								if(typeof currentOverlay !== "undefined") {
									currentOverlay.remove();
								}
															
							}
							
						} catch(e) {
							
						}
																		
						//$.overlay.currentOverlay.remove();
						$.overlay.currentOverlay = false;
						body.trigger('overlay-hide', ['#' + self.options.overlayId]);
						body.trigger('overlay-removed').unbind('overlay-removed');
					});
				}

				win.unbind('resize.overlay');

				// Return focus to the original target for accessibility
				if ( !$.overlay.overlayFlow ) {
					if($.overlay.originalTarget) {
						$.overlay.originalTarget.removeClass('overlay-open state-disabled');
						self.shiftFocus($.overlay.originalTarget);
						$(document).trigger('updateBuffer.framework');
					}
				}

				self.inited = false;
				
			}
		},
		
		processContent: function() {
			
			var self 	= this,
				overlay	= $.overlay.currentOverlay,
				forms 	= overlay.find('form');
			
			if(!self.inited) {
				
				// Add the arrow markup
				if(self.options.componentPop){
					overlay.append(arrowMarkup);
				}

				// Add the close link
				if(self.options.mode !== 'force' && self.options.closeLink) {
					overlay.append(closeMarkup);
				}
				
				// Setup any ajax links
				overlay.delegate('a.async', 'click', function(e) {
					console.log(e.currentTarget.href);
					self.getContent(e.currentTarget.href);
					return false;
				});
				

				// Setup any close/cancel button links
				overlay.delegate('#close, .close, .cancel', 'click', function() {
					overlay.trigger('close.overlay', [true]);
					return false;
				});
				
			}
			
			// Setup form ajax
			if(forms.length) {
				
				forms.each(function(i, form) {
					
					var form = $(this);
					
					form.data('overlay-form', true);
					form.data('overlay-form-index', i);

					// Add hidden inputs for buttons
					form.delegate('input:submit, button', 'click', function(event) {

						var button		= $(this);
						var name 		= button.attr('name');
						var classes		= button.attr('class').replace(/button/, '');
						var value		= (function() {
							var realValue;
							if($.browser.msie) {
								if(button.is('button')) {
									var buttonHtml = button.html();
									button.html('');
									realValue = button.attr('value');
									button.html(buttonHtml);
								}
							} else {
								realValue = button.attr('value');
							}
							return realValue;
						})();
						var input		= $('<input type="hidden" name="' + name + '" class="' + classes + '" value="' + value + '"/>');
						var inputFound	= button.parent().find('input[name="' + name + '"]').length;
						if(!inputFound) {
							button.after(input);
						}
					});

					self.submitHandler(form);
					
				});
			}
		},
		
		submitHandler: function(form) {
			
			var self				= this,
				formIndex			= form.data('overlay-form-index'),
				formEvents 			= form.data('events'),
				validate 			= self.options.validate,
				validationObj		= Target.validation,
				validationArgs		= validationObj.length ? validationObj[formIndex] : validationObj,
				sync				= form.find('input, button').hasClass('sync'),
				returnValue			= true,
				pauseSubmitHandlers,
				submitHandler,
				action;
				
			
			$.overlay.currentOverlay.bind('overlay-show', function(e) {
				
				$.overlay.currentOverlay.unbind(e);
				
				// Move the validation object's submitHandler to pausesubmit.overlay event
				if(validate && validationArgs.submitHandler) {
					form.bind('pausesubmit.overlay', {
						submitHandler: validationArgs.submitHandler
					}, function(e) {
						e.data.submitHandler.call(form.data('validator'), form.get(0));
					});
					delete validationArgs.submitHandler;
				}
				
				// Define the length of pausesubmit.overlay handlers
				pauseSubmitHandlers = (formEvents && formEvents.pausesubmit)
					? formEvents.pausesubmit.length - 1
					: 0;

				// Bind resumesubmit.overlay and run the submit handler (only one is supported).
				// The submit handler runs when all pausesubmit.overlay handlers have been executed
				if(formEvents && formEvents.submit) {
					form.bind('resumesubmit.overlay', {
						submitHandler: formEvents.submit[0].handler
					}, function(e) {
						(!pauseSubmitHandlers--) && e.data.submitHandler.call(form.get(0), e);
					});				
				}
				// Bind resumesubmit.overlay and run the default handler.
				// The default handler runs when all pausesubmit.overlay handlers have been executed
				else {
					form.bind('resumesubmit.overlay', function(e) {
						if(!pauseSubmitHandlers--) {
							if(sync) {
								form.get(0).submit();
							} else {							
								self.getContent(form.attr('action'));
							}
						}
					});
				}
				
				// Bind the submit.overlay
				form.unbind('submit').bind('submit.overlay', function(e) {
					
					e.preventDefault();
										
					action = (formEvents && formEvents.pausesubmit) ? 'pausesubmit' : 'resumesubmit';

					validate
					&& form.validate(validationArgs).form()
					&& $.overlay.currentOverlay.trigger('overlay-loading')
					&& form.trigger(action + '.overlay');
					
					!validate
					&& $.overlay.currentOverlay.trigger('overlay-loading')
					&& form.trigger(action + '.overlay');
				});
								
			});
		
		},
				
		position: function() {
			
			var self = this;
			
			// Atomic position: If an 'x' or 'y' value was set
			if(self.options.x || self.options.y) {
				return {
					x: (self.options.x) ? self.options.x + 'px' : 0,
					y: (self.options.y) ? self.options.y + 'px' : 0
				}
			}

			var win				= $(window);
			var winWidth		= win.width();
			var winHeight		= win.height();
			var core			= $('#Core');
			var scrolltop		= win.scrollTop();
			var scrollleft		= win.scrollLeft();
			var layer			= (self.options.overlayType === 'layer');
			var modal			= (self.options.overlayType === 'modal');
			var targetAbove		= (self.options.position === 'targetAbove');
			var targetCenter	= (self.options.position === 'targetCenter');
			var targetBelow		= (self.options.position === 'targetBelow');
			var posElement		= self.options.position;
			var templateWidth 	= $.overlay.currentOverlay.width();
			var templateHeight 	= $.overlay.currentOverlay.height();
			var tooTall			= templateHeight > winHeight ? scrolltop + 10 + 'px' : false;
			var defaultPosition	= {
				x: ((winWidth - templateWidth) / 2) + 'px',
				y: tooTall ? tooTall : ((winHeight - templateHeight) / 2 + scrolltop) + 'px'
			}

			// Layers need a bit more care to determine position
			if(layer) {
				if(!self.element) {
					if(self.options.position.jquery && !self.options.position.is('body') && self.options.position.length) {
						var posTarget		= self.options.position;
						var posTargetTop	= posTarget.offset().top;

						if(scrolltop > posTargetTop) {
							$('html, body').animate({
								scrollTop: posTargetTop - 10
							}, 'fast');
						}
						return {
					  		x: posTarget.offset().left + 'px',
					  		y: posTarget.offset().top + 'px'
					  	}
					} else {
						return defaultPosition;
					}
				}
 				
				var targetWidth	= self.element.width();
				var targetTop  	= self.element.offset().top;
				var targetLeft 	= self.element.offset().left;
				var targetRight	= targetWidth + targetLeft;
				var offset 		= self.getViewportOffset({
					viewportWidth: winWidth,
					viewportTop: scrolltop,
					positionRight: targetRight + templateWidth,
					positionTop: targetTop - (templateHeight / 2)
				});
				
				// If the event target is provided, position relative
				if(targetAbove) {
					return {
						x: targetRight - offset.x + 'px',
						y: tooTall ? tooTall : targetTop + offset.y - templateHeight + 'px'
					}
				} 
				
				else if(targetCenter) {
					return {
						x: ( winWidth - templateWidth ) / 2 + scrollleft + 'px',
						y: ( winHeight - templateHeight ) / 2 + scrolltop + 'px'
					}
				}
				
				else if(targetBelow) {
					return {
						x: targetRight - offset.x + 'px',
						y: targetTop + offset.y + 'px'
					}
				}
				
				// If a selector was provided, traverse up from the target and position relative
				else if(self.options.position.jquery && !self.options.position.is('body') && posElement.length) {

					var relParent 			= self.element.closest(posElement);
					var referencePoint		= relParent.length ? relParent : posElement
					var referencePointTop	= referencePoint.offset().top;
					
					if(scrolltop > referencePointTop) {
						$('html, body').animate({
							scrollTop: referencePointTop - 10
						}, 'fast');
					}
					return {
				  		x: referencePoint.offset().left + 'px',
				  		y: referencePoint.offset().top + 'px'
				  	}
				}
				
				// If no position was specified use the default
				else {
					return defaultPosition;
				}
			}
			
			// Modals get the default position
			if(modal) {
				return defaultPosition;
			}
						
		},
		
		preloader: function(action) {
			
			var win,
			    winWidth,
			    winHeight,
			    scrolltop,
			    wLoader,
			    hLoader,
			    self = this;
						
			if(action === 'hide') {
				self.loadAnimation.hide();
			} else {
			    
			    win         = $(window);
                winWidth    = win.width();
                winHeight   = win.height();
                scrolltop   = win.scrollTop();
                wLoader     = self.loadAnimation.width();
                hLoader     = self.loadAnimation.height();
                wBody       = self.body.width();
                hBody       = self.body.height();


				self.loadAnimation.hide();
				self.loadAnimation.css({
					top: (winHeight / 2) - (hLoader / 2),
					left: (winWidth / 2) - (wLoader / 2),
					width: '874px'
				});
				self.loadAnimation.fadeIn();
			}
		},
		
		getViewportOffset: function(position) {
			
			var offset = {
				x: 0,
				y: 0
			};
			
			if(position.positionRight > position.viewportWidth) {
				offset.x = position.positionRight - position.viewportWidth + 10;
			}
			
			if(position.viewportTop > position.positionTop) {
				offset.y = position.viewportTop - position.positionTop + 10;
			}
			
			return offset;
			
		},

		consolidateOptions: function() {

			var self 		= this,
				options		= self.options,
				hrefOptions = {},
				sameHandling;			

			// Get all the configuration details
			// All variables are checked in the element's class/href first and
			// then in the options passed to the plugin (for manual instantiation)
			self.element
			&& (self.element.attr('href') !== undefined)
			&& (hrefOptions = self.parseQueryString(self.element.attr('href')));

			// The following options get processed the same;
			//gMap - Gomez Map Obj
		    //gMapVal - Gomez Map Overlay value
			sameHandling = ['x', 'y', 'mode', 'data', 'width', 'height', 'template', 'overlayId', 'image', 'gMap', 'gMapVal'];
			$.each(sameHandling, function(i, name) {
				self.options[name] = (hrefOptions[name] !== undefined) ? hrefOptions[name] : options[name];
			});
			
			// The following options have special processing
			self.options.position =
				(/^target/.test(hrefOptions.position))
				? hrefOptions.position
				: $(hrefOptions.position).eq(0).length && $(hrefOptions.position).eq(0) || $(self.options.position);

			self.options.overlayType =
				(hrefOptions.overlayType !== undefined) ? hrefOptions.overlayType
				: (self.element) && self.element.hasClass('layer') ? 'layer'
				: (self.element) && self.element.hasClass('modal') ? 'modal'
				: self.options.overlayType;
				
			self.options.content =
				(hrefOptions.content !== undefined) ? hrefOptions.content
				: (self.options.content) ? self.options.content
				: (self.element) ? self.element.attr('href')
				: self.options.content;

			self.options.closeLink =
				(hrefOptions.closeLink !== undefined)
				? hrefOptions.closeLink === 'true'
				: self.options.closeLink;

			self.options.validate =				
				($.validator)
				? (hrefOptions.validate !== undefined) && (hrefOptions.validate === 'true') || self.options.validate
				: false;
				
			self.options.passForm =
				(hrefOptions.passForm !== undefined)
				? $(hrefOptions.passForm).eq(0).length && $(hrefOptions.passForm).eq(0) || false
				: self.options.passForm;
						
			if((self.options.content === '' || self.options.content === '#' || !self.options.content) && !self.options.contentOverride) $.overlay.exception('self.options.content and self.options.contentOverride are false.');
		},
		
		parseQueryString: function(href) {

			var collection	= {};
			var querystring	= href.split('?')[1];
			var pairs;

			if(!querystring) return false;

			querystring	= decodeURI(querystring);
			pairs	 	= querystring.split("&");

			for(var i = 0; i < pairs.length; i++) {
			    if(!pairs[i]) {
			        continue;
			    }
			    var seperatorPosition = pairs[i].indexOf("=");
			    if(seperatorPosition == -1) {
			        collection[pairs[i]] = "";
			    } else {
			    	collection[pairs[i].substring(0, seperatorPosition)] = pairs[i].substr(seperatorPosition + 1).replace(/#amp#/,'&');
			    }
			}
			return collection;
		}
		
	}
	
})(jQuery);

// Let the base framework know about us.
$(window).trigger('register.framework', ['plugin', 'Overlay', $.overlay.registration]);

// Auto instantiation. Uses delegate(). No need for ready() wrapper.
// Can be moved to a global file if needed.
$('.modal:not(.overlay), .layer:not(.overlay)').overlay();