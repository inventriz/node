Target.register("controller", "globalUtils", {
	init : function () {
		this.loadInterface()
	},
	loadInterface : function () {
		var a = this,
		b = function () {
			var f = new Date,
			g = f.getMonth() + 1;
			f = f.getDate();
			var j = [];
			months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
			return j = {
				month : months[g - 1],
				day : f
			}
		}
		();
		$(".getDay").html(b.day);
		$(".getMonth").html(b.month);
		b = $("#QuickView #isPortableQIFlag");
		var d = typeof b !== "undefined" ? b.attr("rel") : "false";
		$("body").delegate("#QuickView", "overlay-before-show", function () {
			if (d !==
				"true")
				if ($(this).find(".component-carousel-3").length > 0)
					a.checkIfCarousal(".component-carousel-3");
				else
					$(this).find(".component-carousel-4").length > 0 && a.checkIfCarousal(".component-carousel-4")
		});
		$("body").delegate(".WATAgging", "click", function () {
			console.log("lnk", $(this).parent().siblings("input.lnk").val());
			var f = $(this).parent().siblings("input.lnk").val();
			try {
				s_clickInteraction("Page Name: promotion link", f)
			} catch (g) {
				console.log(g.message)
			}
		});
		a.checkIfCarousal(".component-carousel-1");
		d !== "true" &&
		a.checkIfCarousal(".component-carousel-3");
		a.checkIfCarousal(".component-carousel-4");
		a.checkIfCarousal(".component-carousel-5");
		a.checkIfCarousal(".component-carousel-6");
		a.checkIfCarousal(".component-carousel-recmm-4");
		a.expandDescComponent();
		a.imgMap();
		a.recurringMethod();
		a.updateESRBCookieValue();
		$("#blockDVMCall").length == 0 && a.DvmAdInit();
		$(".CMS-t1 .category-link").delegate("li a.offer-overlay", "click", function (f) {
			f.preventDefault();
			var g = $(this).offset();
			f = parseInt(g.left) - 128;
			g = parseInt(g.top) +
				20;
			var j = this.href;
			$(this);
			$.overlay.load({
				content : j,
				overlayType : "layer",
				x : f,
				y : g,
				width : 350,
				overlayId : "offerOverlayView",
				closeLink : true,
				componentPop : true
			})
		});
		$("body").bind("overlay-hide", function (f, g) {
			g === "#offerOverlayView" && $(void 0).focus()
		});
		$("body").delegate(".wide-ft-category-images.three-category-images > ul li, .wide-ft-category-images.four-category-images > ul li", "focusout mouseenter mouseleave click", function (f) {
			var g = f.type,
			j = $(f.target),
			l = $(this),
			o = l.find(".productContainer"),
			v = l.find(".productOverDetails");
			l = function () {
				o.show();
				v.hide();
				o.parent("li").removeClass("selected")
			};
			try {
				var A = j.closest(".productOverDetails").find("ul.bottom-category-links li").length,
				C = j.closest(".productOverDetails").find("ul.category-links li").length,
				q = j.parent("li").is(":last-child"),
				I = j.parent("li").parent().is("ul.bottom-category-links"),
				K = j.parent("li").parent().is("ul.category-links");
				if (A && q && I || C && !A && q && K)
					l()
			} catch (Q) {}
			if (g == "click" && j.is(".product-title a.npcatTitle")) {
				f.preventDefault();
				$(".productContainer").show();
				$(".productOverDetails").hide();
				j.closest("div").next("div.productOverDetails").show();
				j.closest("div.productContainer").hide();
				j.closest("li").find("div.productOverDetails p.product-title a").focus();
				j.closest("li").addClass("selected")
			}
			if (g == "mouseover") {
				o.hide();
				v.show();
				o.parent("li").addClass("selected")
			} else
				g == "mouseout" && l()
		});
		$("body").delegate("#addtocart.overlay a", "click", function () {
			var f = $(this).attr("title"),
			g = $(this).parent().attr("class").indexOf("legalnote");
			if (f !== "undefined" && g !==
				"undefined")
				if (f == "view cart")
					try {
						s_cartOverlayInteraction("lnk_crt_editcart")
					} catch (j) {
						console.log(j.message)
					}
				else if (f == "Continue Shopping") {
					$.overlay.currentOverlay.trigger("close.overlay", [true]);
					try {
						s_clickInteraction("ATC Layer: Continue Shopping")
					} catch (l) {
						console.log(l.message)
					}
				} else if (g != -1)
					try {
						s_clickInteraction("ATC Layer: View our return policy")
					} catch (o) {
						console.log(o.message)
					}
		});
		$("body").delegate("#addtocart", "overlay-before-hide", function () {
			document.activeElement.id == "close" && typeof s_clickInteraction !=
			"undefined" && s_clickInteraction("ATC Layer: Close Overlay")
		})
	},
	showProgress : function (a) {
		animationstart = function () {
			a.find(".progressbar").animate({
				width : "100%"
			}, 1500, function () {
				animationstop()
			})
		};
		animationstop = function () {
			a.find(".progressbar").animate({
				width : "0"
			}, 0);
			animationstart()
		};
		animationstart()
	},
	addlistModError : function (a) {
		a.prepend('<p style="position: absolute;top: -13px;width: 100%;color:#c00;" class="itemnotaddedlist">item not added to list</p>');
		a.find("#addToListPDP").html("please try again")
	},
	clearAddtoList : function (a) {
		a = !a ? $(".addtolistbutton") : a;
		a.html(Target.controller.header.listModHTML)
	},
	addtolistMOD : function (a, b) {
		Target.controller.header.unSerialize(a);
		currentTarget = b.parents("li.addtolistbutton");
		if (!Target.controller.header.listModHTML)
			Target.controller.header.listModHTML = currentTarget.html();
		currentTarget.find(".itemnotaddedlist").remove();
		currentTarget.find("#addToListPDP").html("add to list");
		currentTarget.addClass("progressing").find("#addToListPDP").append('<div class="progressbar" style="z-index:2;position:absolute;left:2px;bottom:1px;background:#c00;height:2px;border-radius:4px"></div>').focus();
		Target.controller.header.cookie.erase("listcallbackUrl");
		this.showProgress(currentTarget);
		$.ajax({
			type : "POST",
			url : a,
			datatype : "JSON",
			curtain : false,
			success : function (d) {
				currentTarget.find(".progressbar").remove();
				if (d != "")
					if (typeof d == "object" && typeof d.ListModJSON != "undefined") {
						_isSuccess = !!d.ListModJSON.Success;
						_isFailure = !!d.ListModJSON.Failure;
						if (_isSuccess) {
							currentTarget.find(".listmainblock").addClass("added").focus();
							setTimeout(function () {
								currentTarget.addClass("viewinglist").focus()
							}, 1200)
						} else if (_isFailure) {
							currentTarget.prepend('<p style="position: absolute;top: -15px;width: 100%;color:#c00;">' +
								d.ListModJSON.FailureMessage + "</p>");
							d.ListModJSON.ErrorCode == "5001" ? currentTarget.find("#addToListPDP").html("edit your list").attr("href", currentTarget.find(".viewlist a").attr("href")) : currentTarget.find("#addToListPDP").html("please try again")
						}
					} else if (eval("(" + d + ")").overLayId == "registrySignin") {
						Target.controller.header.cookie.create("listcallbackUrl", a);
						Target.controller.globalUtils.openLoginPopUp()
					} else
						Target.controller.globalUtils.addlistModError(currentTarget);
				else
					Target.controller.globalUtils.addlistModError(currentTarget)
			},
			error : function () {
				currentTarget.find(".progressbar").remove();
				Target.controller.globalUtils.addlistModError(currentTarget)
			}
		})
	},
	addToListColCallback : function (a, b) {
		var d = $(b),
		f = d.closest("li.CollectionItem").attr("parentid"),
		g = $("#OrderItemAddForm_catEntryId_" + f).val(),
		j = $("#quantity_" + f).val(),
		l = $("#listModeFlag").length > 0 && $("#listModeFlag").val() == "Y" ? "Y" : "N";
		f = a == null && $("#OrderItemAddForm_" + f).valid() ? true : a != null && a != "" ? true : false;
		Target.controller.header.cookie.erase("listcallbackUrl");
		var o =
			d.closest("li.addtolistbutton"),
		v = d.children("span").first(),
		A = d.find("span.progressAnnounce");
		if (a == null) {
			a = $(b).attr("rev");
			a += "&catEntryId_0=" + g + "&quantity_0=" + j;
			if (l == "Y")
				a += "&colItem=" + $(b).attr("id")
		}
		o.find("p.error").remove();
		if (f) {
			Target.controller.globalOverlay.setAxbFocusElem(d);
			if (l == "Y") {
				$(".itemnotaddedlist").remove();
				d.find(".progressAnnounce").text("Adding to list is in progress");
				d.append('<div class="progressbar"></div>');
				var C = function () {
					$(".progressbar").animate({
						width : "100%"
					},
						1500,
						function () {
						$(".progressbar").animate({
							width : "0"
						}, 0);
						C()
					})
				},
				q = function (I, K) {
					var Q = $("<p>").addClass("error").html(I);
					o.prepend(Q);
					A.text(K)
				};
				C();
				o.find("p.error").remove();
				$.ajax({
					type : "POST",
					url : a,
					datatype : "JSON",
					curtain : false,
					success : function (I) {
						d.find(".progressbar").remove();
						if (typeof I == "object" && typeof I.ListModJSON != "undefined" && typeof I.ListModJSON.Success != "undefined") {
							A.empty();
							d.addClass("positive");
							v.text("added to list");
							d.attr("href", "/targetlists");
							d.removeClass("addToListCol");
							d.attr("tabindex", 0).focus();
							setTimeout(function () {
								v.text("view your list");
								d.removeClass("positive").attr("tabindex", 0).focus()
							}, 2E3)
						} else if (typeof I == "object" && typeof I.ListModJSON != "undefined" && typeof I.ListModJSON.Failure != "undefined") {
							if (I.ListModJSON.ErrorCode == "5001") {
								q(I.ListModJSON.FailureMessage, "there are too many items on the your list, please edit your list before adding more items.");
								v.text("edit your list");
								d.attr("href", "/targetlists");
								d.removeClass("addToListCol")
							} else {
								q(I.ListModJSON.FailureMessage,
									"an error occurred, please try again");
								v.text("please try again")
							}
							d.attr("tabindex", 0).focus()
						} else {
							Target.controller.header.cookie.create("listcallbackUrl", a);
							Target.controller.globalUtils.openLoginPopUp()
						}
					},
					error : function () {
						d.find(".progressbar").remove();
						q("system error occurred");
						v.text("please try again");
						A.text("an error occured, please try again");
						d.attr("tabindex", 0).focus()
					}
				})
			} else
				Target.controller.grda.HandleGRDAResponse(a, function () {}, false)
		}
	},
	openLoginPopUp : function () {
		var a = window.location.pathname.substring(1);
		Target.controller.header.cookie.create("basePageURLForPOPup", a);
		typeof Target.globals.loginPopupURL != "undefined" && window.open(Target.globals.loginPopupURL, "signWindow", "scrollbars=yes, resizable=yes, location=yes, top=" + (window.innerHeight / 2 - 175) + ", left=" + (window.innerWidth / 2 - 350) + ", width=760, height=400")
	},
	updateESRBCookieValue : function () {
		var a = Target.controller.reviewed.cookie.read("esrbResponse");
		typeof a != "undefined" && a != "" && $("#esrbResponse").val(a)
	},
	checkIfCarousal : function (a) {
		console.log('here111');
		var b = $(a);
		console.log(b.length);
		b.length > 0 && b.each(function () {
			console.log($(this).data("checked-carousal"));
			if (!($(this).data("checked-carousal") != null || $(this).find("li:first").hasClass("carousel-panel"))) {
				$(this).data("checked-carousal", true);
				$(this).parents("div.section").show();
				var d = $(this).find(">li").length,
				f = parseInt(a.replace(/[.a-zA-Z-]+/i, "")),
				g = $(this).hasClass("loop") ? true : false,
				j = $(this).hasClass("pagination") ? true : false,
				l = $(this).hasClass("autoRotate") ? true : false;
				g = l ? true : false;
				var o = $(this).hasClass("encapsulated") ? true : false,
				v = $(this).hasClass("displayCount") ?
					true : false,
				A = $(this).hasClass("paginationCount") ? true : false;
				if (d)
					if (f < d) {
						d = {
							increment : f,
							pagination : j,
							centerPagination : false,
							encapsulateControls : o,
							displayCount : v,
							paginationCount : A,
							autoRotate : l,
							pingPong : false,
							loop : g
						};
						if ($.browser.msie && $(".primaryImgContainer").length)
							d = $.extend(true, d, {
									postFrameChange : function () {
										var q = $(".primaryImgContainer a.nextFrame"),
										I = $(".primaryImgContainer a.prevFrame");
										if (q.length) {
											q.css({
												backgroundPosition : "-396px -1426px"
											});
											q.live("hover", function () {
												q.attr("style", "backgroundPosition:-385px -1426px;")
											})
										}
										if (I.length) {
											I.css({
												backgroundPosition : "-374px -1426px"
											});
											I.live("hover", function () {
												I.attr("style", "backgroundPosition:-363px -1426px;")
											})
										}
									}
								});
						if ($("#media-player.vms").length || $("#ProductDetailsTop").length) {
							if ($("#media-player.vms").length)
								var C = "#media-player ul li.component-container.carousel-panel";
							else if ($("#ProductDetailsTop").length)
								C = "#ProductDetailsTop ul li.component-container.carousel-panel";
							d = $.extend(true, d, {
									stateChange : function () {
										$(C).removeAttr("aria-hidden");
										$(C + ".state-visible").attr("aria-hidden", "false");
										$(C + ".state-hidden").attr("aria-hidden",
											"true")
									}
								})
						}
						$(this).tileCarousel(d)
					} else
						$(this).tileCarousel({
							increment : d,
							skipNav : true
						})
			}
		})
	},
	expandDescComponent : function () {
		$("a.waRRtag, a.expandDesc").each(function () {
			if ($(this).children().length == 0) {
				var a = $(this),
				b = a.text(),
				d = a.attr("title");
				a.bind("mouseover focus", function () {
					$(this).html("").append(d)
				});
				a.bind("mouseout blur", function () {
					$(this).html("").append(b)
				});
				a.bind("mousedown", function () {
					$(this).unbind("focus")
				})
			}
		})
	},
	PDPRRexpandDescComponent : function () {
		$("a.waRRtag, a.expandDesc").each(function () {
			var a =
				$(this),
			b = a[0].firstChild.textContent;
			title = a.attr("title");
			a.bind("mouseover focus", function () {
				a.text(title)
			});
			a.bind("mouseout blur", function () {
				a.text(b)
			});
			a.bind("mousedown", function () {
				a.unbind("focus")
			})
		})
	},
	renderRRfromJson : function (a, b, d) {
		var f = 0;
		templateToUse = "";
		templateToUse = typeof renderRRfromJsonVarstemp != "undefined" ? a + "_temp" in renderRRfromJsonVarstemp ? renderRRfromJsonVarstemp[a + "_temp"] : renderRRfromJsonVars[a] : renderRRfromJsonVars[a];
		for (var g in RR.data.JSON.placements)
			if (RR.data.JSON.placements[g].placement_name ==
				b) {
				responseobj = RR.data.JSON.placements[g];
				f = 1;
				if ("collapse" in templateToUse.placementvalues)
					if ("minresponsedata" in templateToUse.placementvalues.collapse)
						if (responseobj.items.length <= templateToUse.placementvalues.collapse.minresponsedata)
							f = 2;
				break
			}
		if (!(f == 0 || f == 2)) {
			a = {};
			for (var j in templateToUse)
				a[j] = templateToUse[j];
			j = "";
			f = responseobj.items;
			g = "";
			var l = /\<[a-zA-Z0-9\"\'\=\s\#]*(type=['"]checkbox['"])[a-zA-Z0-9\"\'\s\=\#]*\/\>/gi,
			o = /(<!--startscreenreaderonly--\>)[\'\<a-zA-Z0-9\-\>\\\#\s\=\-\/]+(<!--endscreenreaderonly--\>)/gi,
			v;
			for (v in templateToUse) {
				if (v.indexOf("placementvalues") == -1) {
					if (v.indexOf("loop") > -1) {
						j = "";
						if (v.indexOf("loopfirstitem") > -1)
							f = [f[0]];
						for (var A in f) {
							var C = templateToUse[v],
							q = 0,
							I = "";
							if ("collapse" in templateToUse.placementvalues)
								if ("maxresponsedata" in templateToUse.placementvalues.collapse)
									if (A == templateToUse.placementvalues.collapse.maxresponsedata)
										break;
							var K = f[A].channel;
							if (K.indexOf(" ") > -1)
								K = K.replace(/\s/gi, "");
							if (K == "storeonly") {
								if (f[A].soipricedisplay == "N")
									I += templateToUse.placementvalues.pricevarybystore +
									templateToUse.placementvalues.storemessages;
								else if (f[A].soipricedisplay == "Y") {
									q = 1;
									K = "";
									K = f[A].salePriceMax == f[A].salePriceMin ? templateToUse.placementvalues.isStandaloneSalesPrice : templateToUse.placementvalues.isRangeSalesPrice;
									K = K.replace(o, "");
									I += K + templateToUse.placementvalues.storepricemsg
								}
								if (C.match(l))
									C = C.replace(l, "")
							} else
								I += f[A].mapflag == "Y" && (K == "online" || K == "webonly" || K == "crossover") ? templateToUse.placementvalues.seelowprice : f[A].salePriceMax != "" && f[A].salePriceMin != "" ? f[A].salePriceMax ==
								f[A].salePriceMin ? templateToUse.placementvalues.isStandaloneSalesPrice : templateToUse.placementvalues.isRangeSalesPrice : templateToUse.placementvalues.isStandaloneSalesPrice;
							if (f[A].priceMax != "" && f[A].priceMin != "")
								if (f[A].priceMax != f[A].salePriceMax || f[A].priceMin != f[A].salePriceMin)
									I += f[A].priceMax != f[A].priceMin ? templateToUse.placementvalues.isRangeOriginalPrice : templateToUse.placementvalues.isStandaloneOriginalPrice;
							if (q == 1)
								I += templateToUse.placementvalues.storemessages;
							if (f[A].primaryPromoDescription ==
								"")
								C = C.replace(globalhtmlreplace.promoText, "");
							if (f[A].relationItemType == "VAP")
								C = C.replace("<li", "<li variation='true'");
							C = C.replace(/#pricedisplay#/, I);
							if (f[A].productReviews == "")
								C = C.replace(/((<!-- start product rating --\>)[\'\<a-zA-Z0-9\-\>\#\!\s*\/\=\.\%\_\&\*\@\;\?\:\)\(\|]+(<!-- end product rating --\>))/gi, "");
							j += d == "#dlpRightRail_2" || d == ".perso-pdpvertical-3" ? this.multipleMatchFunction(C, templateToUse.placementvalues.placementdata, f[A], d) : this.multipleMatchFunction(C, templateToUse.placementvalues.placementdata,
								f[A], f[A], A == 0 ? "" : d)
						}
						templateToUse[v] = v.indexOf("loopfirstitem") > -1 ? j : "<ul>" + j + "</ul>"
					} else if (templateToUse.placementvalues.placementdata.length > 1)
						templateToUse[v] = this.multipleMatchFunction(templateToUse[v], templateToUse.placementvalues.placementdata, responseobj, d, A == 0 ? "" : d);
					g += templateToUse[v]
				}
				templateToUse[v] = a[v]
			}
			$(d).html(g);
			d = templateToUse.placementvalues;
			if ("componentseperator" in d)
				if (b in d.componentseperator)
					if ("lineseperator" in d.componentseperator[b]) {
						b = d.componentseperator[b];
						d = b.lineseperator;
						if (d != "") {
							$(b.lineplaceholer + d).addClass(b.classname);
							"checkboxcheck" in b && $(b.lineplaceholer + d).find(b.checkboxcheck) && $(b.lineplaceholer + d + b.checkboxcheck).attr("checked", "checked");
							"addhtmlcontent" in b && $(b.addhtmlcontent).insertAfter(b.lineplaceholer + d)
						}
					}
			Target.controller.globalUtils.expandDescComponent();
			Target.controller.globalUtils.checkIfCarousal(".component-carousel-1");
			Target.controller.globalUtils.checkIfCarousal(".component-carousel-3");
			Target.controller.globalUtils.checkIfCarousal(".component-carousel-4");
			Target.controller.globalUtils.checkIfCarousal(".component-carousel-5");
			Target.controller.globalUtils.checkIfCarousal(".component-carousel-6")
		}
	},
	setrrImgServer : function (a, b) {
		return window.location.protocol === "https:" ? "https://" + b : "http://" + a
	},
	setrrImgSrc : function (a, b, d, f) {
		a = this.setrrImgServer(a, b) + d;
		b = a.lastIndexOf(".");
		return a.slice(0, b) + "_" + f + "x" + f + a.slice(b, a.length)
	},
	multipleMatchFunction : function (a, b, d, f) {
		var g = "";
		f = f == ".perso-pdpvertical-3" || f == "#dlpRightRail_2" ? 24 : 36;
		for (var j in b) {
			var l =
				b[j].match(/[a-z0-9A-Z\.\-\_]+/);
			if (l in d)
				if (d[l] != "") {
					if (d[l].indexOf("'") > -1)
						d[l] = d[l].replace(/\'/gi, "&#39;");
					pattern = RegExp(b[j], "gi");
					if (l == "rating") {
						a = a.replace(pattern, ratingsclass[d[l]]);
						var o = "";
						d[l].indexOf(".0") > -1 ? o = parseInt(d[l]) : o = d[l];
						a = a.replace(/#screenRating#/gi, o)
					} else if (l == "productlinktitle") {
						if (d[l].length >= f) {
							o = d[l].substring(0, f - 3);
							o += "..."
						} else
							o = d[l];
						a = a.replace(pattern, d[l]);
						a = a.replace(/#producttitledisplay#/gi, o)
					} else if (l.toString().indexOf("PromoDescription") > -1 && a.indexOf("#promotext#") >
						-1)
						g += templateToUse.placementvalues.isPromo.replace(/#promoTextDisplay#/gi, d[l]);
					else
						a = a.replace(pattern, d[l])
				} else {
					pattern = l != "productReviews" ? l == "category" ? /((<!-- startcategory --\>)[\'\<a-zA-Z0-9\-\>\#\!\s*\/\=\.\%\_\&\*\@\;\?\:\)\(\|]+(<!-- endcategory --\>))/gi : RegExp(globalhtmlreplace[l], "gi") : /((<!-- start product rating --\>)[\'\<a-zA-Z0-9\-\>\#\!\s*\/\=\.\%\_\&\*\@\;\?\:\)\(\|]+(<!-- end product rating --\>))/gi;
					a = a.replace(pattern, d[l])
				}
			else if (l.toString().indexOf("custimg_") > -1) {
				l = l.toString().split("_")[1];
				l = this.setrrImgSrc(d.imageServer, d.imageServerSSL, d.image, l);
				a = a.replace(/#custimg#/gi, l)
			} else {
				pattern = l != "productReviews" ? RegExp(globalhtmlreplace[l], "gi") : /((<!-- start product rating --\>)[\'\<a-zA-Z0-9\-\>\#\!\s*\/\=\.\%\_\&\*\@\;\?\:\)\(\|]+(<!-- end product rating --\>))/gi;
				a = a.replace(pattern, "")
			}
		}
		if (g != "")
			a = a.replace(/#promotext#/, g);
		return a
	},
	imgMap : function () {
		$.each($(".imagemp"), function () {
			var a = $(this).attr("cords");
			if (typeof a != "undefined" && a != "null" && $.trim(a) != "")
				if (a.split(",").length ==
					4) {
					if (typeof $(this).parents(".component")[0] != "undefined" && typeof $(this).parents(".component").find(".image-container")[0] != "undefined") {
						$(this).parents(".component").find(".image-container").attr("offsetLeft");
						$(this).parents(".component").find(".image-container").attr("offsetTop")
					} else if (typeof $(this).siblings(".image-container")[0] != "undefined") {
						$(this).siblings(".image-container").attr("offsetLeft");
						$(this).siblings(".image-container").attr("offsetTop")
					}
					var b = parseInt(a.split(",")[2]) - parseInt(a.split(",")[0]) +
						"px",
					d = parseInt(a.split(",")[3]) - parseInt(a.split(",")[1]) + "px",
					f = parseInt(a.split(",")[0]) + "px";
					a = parseInt(a.split(",")[1]) + "px";
					$(this).css({
						left : f,
						top : a,
						width : b,
						height : d
					})
				}
		})
	},
	initRRCarousel : function () {
		
		this.checkIfCarousal(".component-carousel-1");
		this.checkIfCarousal(".component-carousel-3");
		this.checkIfCarousal(".component-carousel-4");
		this.checkIfCarousal(".component-carousel-5");
		this.checkIfCarousal(".component-carousel-recmm-4");
		$(".component-carousel-4coloumns").tileCarousel({
			increment : 4,
			pagination : true,
			centerPagination : false,
			encapsulateControls : true
		});
		this.expandDescComponent()
	},
	calculateAge : function (a, b, d) {
		b = (d + (a <= 9 ? "0" + a : a) + b).match(/(\d{4})(\d{2})(\d{2})/);
		var f = new Date(b[1], b[2] - 1, b[3]);
		b = new Date;
		d = Math.floor((b.getTime() - f.getTime()) / 1E3 / 60 / 60 / 24);
		for (var g = 0, j = f.getFullYear(); j <= b.getFullYear(); j++) {
			f = j % 4 == 0 && (j % 100 != 0 || j % 400 == 0) ? 366 : 365;
			if (!(parseInt(a) >= b.getMonth() + 1 && parseInt(a) >= b.getMonth() + 1 && b.getFullYear() == j))
				if (d >= f) {
					d -= f;
					g++
				}
		}
		return g
	},
	getDemoLinkURL : function (a) {
		var b =
			Target.controller.reviewed.cookie.read("esrbResponse");
		if (b != null && b != "") {
			b = b.split("_");
			var d = $("input[name=ageLimitVer]").val(),
			f = b[1];
			if (b[0] == "YES")
				if (f >= d) {
					b = $("#demoOnClick");
					d = b.attr("rel");
					b.attr({
						href : d,
						target : "_blank"
					});
					b.removeClass("layer");
					a && $("#demoOnClick").trigger("click", ["fromDemoLink"])
				}
		}
	},
	recurringMethod : function () {
		$(".subscribeme").live("click", function () {
			var a = $(this),
			b = a.parents("form.no-summary, #modal-check-low-price").find(".button.addtoCart .buttonText, .addtoCart.state-shaded .buttonText"),
			d = a.parents("form.no-summary, #modal-check-low-price").find(".button.addtoCart, .addtoCart.state-shaded"),
			f = new Date,
			g = f.getDate(),
			j = f.getMonth() + 1;
			f = f.getFullYear();
			var l = a.parents("form.no-summary, #modal-check-low-price").find(".itemLevelService--input");
			a.parents("form.no-summary, #modal-check-low-price").find(".babyalertmsg").remove();
			if (typeof $(this).parents("#ProductDetailsTop")[0] == "undefined") {
				a.is(":checked") ? l.show() : l.hide();
				a.is(":checked") && l.css("display", "table")
			} else if (a.is(":checked")) {
				a.parents("#itemLevelService").animate({
					width : "100%"
				},
					370,
					function () {
					l.show();
					$("#addToCart").html("subscribe")
				});
				l.css("display", "table")
			} else {
				a.parents("#itemLevelService").animate({
					width : "228"
				}, 370, function () {
					l.hide();
					$("#addToCart").html("add to cart")
				});
				a.parents("#itemLevelService").removeClass("expand")
			}
			if (a.closest(".j_primaryInfo").length || a.closest("#qinfo").length) {
				b = a.closest("form.order-item");
				b = b.find("#addToCart").length ? b.find("#addToCart") : b.find("#qiAddToCart");
				d = b.find(".buttonText");
				if (a.is(":checked")) {
					b.hasClass("state-shaded") ?
					b.removeClass("addtoCart").removeClass("state-shaded").addClass("subscribe-faded button") : b.removeClass("addtoCart").addClass("subscribe");
					b.attr("title", "subscribe");
					d.find(".cart-icon").hide();
					d.html("subscribe").attr("title", "subscribe");
					b = $("#staticTextData");
					b = typeof b !== "undefined" ? b.attr("data-json") : null;
					b = (b ? $.parseJSON(b) : null).subscribeShipMsg;
					typeof $(this).parents("#ProductDetailsTop") == "undefined" && $("#.shippingPrmLi .shpPrmMsg").html(b)
				} else {
					b.hasClass("subscribe-faded") ? b.removeClass("subscribe-faded").removeClass("button").addClass("state-shaded").addClass("addtoCart") :
					b.removeClass("subscribe").addClass("addtoCart");
					b.attr("title", "add to Cart");
					d.find(".cart-icon").show();
					d.html("add to cart").attr("title", "add to cart");
					a.closest(".j_primaryInfo").length ? $(".shippingPrmLi .shpPrmMsg").html(Target.controller.productDetails._pdpShipPromoMsg) : $(".shippingPrmLi .shpPrmMsg").html(Target.controller.globalOverlay._quickInfoShipPromoMsg)
				}
			} else {
				a.is(":checked") ? b.html("subscribe") : b.html("add to cart");
				a.is(":checked") ? d.find(".cart-icon").hide() : d.find(".cart-icon").show();
				a.is(":checked") ? d.attr("title", "subscribe") : d.attr("title", "add to cart")
			}
			babySubscribe = a.parents("form.no-summary, #modal-check-low-price").find(".calendar");
			if (g < 10)
				g = "0" + g;
			if (j < 10)
				j = "0" + j;
			curDate = j + "/" + g + "/" + f;
			a = $("#startDate").val();
			$("#endDate").val();
			if (typeof a !== "undefined" && a != "")
				curDate = a;
			babySubscribe.attr("value", curDate)
		})
	},
	recurringOrderValidate : function (a, b) {
		var d = b.parents("form.no-summary").find(".babyalertmsg"),
		f = b.parents("form.no-summary").find(".itemLevelService");
		d.remove();
		f.before('<p style="clear: both;" class="error-message babyalertmsg" id="babyalertmsg">please uncheck subscribe to add this item to your ' + a + "</p>");
		setTimeout(function () {
			$(document).trigger("updateBuffer.framework");
			$("#babyalertmsg.babyalertmsg").attr({
				role : "alert",
				tabindex : "-1"
			}).focus()
		}, 1E3)
	},
	RRAddToCart : function () {
		var a = "";
		$("#rr_addtocart, #addToCartOverlay").click(function () {
			function b(o, v) {
				var A = 0;
				o.find(" > li").each(function () {
					var C = $(this).find("input[type='checkbox']:checked");
					$.inArray(C.val(),
						v) >= 0 && A++
				});
				return A
			}
			var d = 0,
			f = "";
			a = "";
			if ($(this).hasClass("state-disabled") !== true) {
				$("#item_page-pdp_horizontal_2 li").find("input:checked").each(function (o) {
					if (o > 0)
						a += "&";
					a = a + "partNumber_" + o + "=" + $(this).val() + "&quantity_" + o + "=1"
				});
				$.ajaxSetup({
					traditional : true,
					cache : false
				});
				var g = Target.controller.reviewed.cookie.read("esrbResponse");
				if (g != null && g != "")
					a = a + "&esrbResponse=" + g;
				$.ajax({
					url : "/checkout_itemadd?" + a + "&fromScript=true&overlay=true&fromRR=Y&errorViewName=ErrorResponse",
					dataType : "json",
					type : "POST",
					success : function (o) {
						if (typeof o.errorMessage != "undefined" && o.errorMessage != "" && o.errorMessage != null)
							if (o.errorMessageKey == "ESRBRATING_MATURE_TEXT" || o.errorMessageKey == "ESRBRATING_FAILURE")
								j(o);
							else {
								o = "<div class='errorBlock' style='float:right;margin-top:0px;clear:both;'>" + o.errorMessage + "</div>";
								$(".errorBlock").remove();
								$("#item_page-pdp_horizontal_2").children().length > 0 && $("#item_page-pdp_horizontal_2").after(o)
							}
						else
							o.partNumWithOOS != null && typeof o.partNumWithOOS != "undefined" && o.partNumWithOOS !=
							"" ? l(o) : j(o)
					}
				});
				var j = function (o) {
					$.overlay.load({
						contentOverride : o.responseHtml,
						overlayId : o.overlayId,
						template : o.template,
						mode : false,
						target : "#rr_addtocart"
					});
					formerrordisplay("", o.productId)
				},
				l = function (o) {
					var v = 0;
					partNumberOutOfStockList = o.partNumWithOOS;
					var A = $("#rr_addtocart").parent().prev(),
					C = "<img class='img-soldout' src='" + $("#oosImagePath").val() + "'  alt='sold out' />",
					q = 0;
					o = "";
					var I = b(A, partNumberOutOfStockList);
					A.find(" > li").each(function () {
						var p = $(this).find("input[type='checkbox']:checked");
						if (typeof p.val() != "undefined")
							if ($.inArray(p.val(), partNumberOutOfStockList) >= 0) {
								if (d == 0) {
									$(this).find("input[type='checkbox']:checked").replaceWith("");
									$(this).find("a.layer:first").after(C);
									p = "";
									p = $(this).find("a.layer:first > img").attr("alt");
									if (p.indexOf("quick info") > -1)
										p = p.replace("quick info", "");
									$(this).find("a.layer:first > img").attr("alt", p);
									$(this).find("label").remove();
									$(this).find("a.layer:first > img").unwrap().wrap("<p class='pImage' style='display:inline'></p>");
									$(this).find("a").click(function (r) {
										r.preventDefault()
									});
									$(this).find("a").attr("href", "");
									cloneli = $(this).clone();
									$(this).find(".small-product-image").length > 0 ? productimage = cloneli.find(".small-product-image,.product-image")[0].outerHTML : productimage = cloneli.find(".product-image")[0].outerHTML;
									$(this).find(".small-product-price").length > 0 ? productprice = cloneli.find(".small-product-price,.product-price")[0].outerHTML : productprice = cloneli.find(".product-price")[0].outerHTML;
									$(this).find(".small-product-name").length > 0 ? productname = cloneli.find(".small-product-name,.product-name")[0].outerHTML :
										productname = cloneli.find(".product-name")[0].outerHTML;
									v += 1;
									p = v;
									p = "<div class='RRaddtoCartOverlay'><span class='spandottedImg'>............</span>" + p + " of " + I + "<span class='spandottedImgRight'>............</span></div>";
									f += I > 1 ? "<li>" + p + productimage + productprice + productname + "</li>" : productimage + productprice + productname
								}
							} else
								typeof p.val() != "undefined" && q++
					});
					if (I > 1)
						f = "<div id='ModalCarousel' class='modelCarouselDisp'><ul class='component-carousel-1'>" + f + "</ul></div>";
					A = f;
					if (q > 0)
						o = "<div class='addinstockitems'><p class='reviewerrorweight'>Add in-stock items to my cart.</p> <a id='addToCartOverlay' class='button rraddtocart layer' title='add items to cart' name='addToCartOverlay' href='#'><span class='buttonText'>add to cart</span></a></div>";
					else
						$(".rraddtocart").addClass("state-disabled");
					var K = $("#reviewSelectionError").val(),
					Q = $("#reviewError").val(),
					n = $("#oosError").val(),
					G = $("#oosMsg").val();
					$.overlay.load({
						contentOverride : "<div class='main-content'><h2>" + G + "</h2>" + ("<div class='add2cartnew-leftside add2cartnew-leftside-width'>" + A + ("<div class='quantityOOSMessage'><div class='dispQuantity'>Quantity : <span>1</span></div><div class='OOSError'>" + n + "</div></div>") + "</div>") + ("<div class='add2cartnew-rightside add2cartnew-rightsidealignment'><p>" +
							K + "</p>" + o + "<div class='addinstockitems'><p class='reviewerrorweight'>" + Q + "</p><button title='review items' class='button addtoCart' id='reviewitems' value='1' name='reviewitems' type='submit'><span class='buttonText'>Review Items</span></button></div></div>") + "</div>",
						target : "#rr_addtocart"
					});
					$("#overlay").addClass("OOS-Overlay");
					$("#addToCartOverlay").click(function () {
						$(".checkBoxTree").trigger("click");
						$("#rr_addtocart").trigger("click")
					});
					$("#reviewitems").click(function () {
						$.overlay.currentOverlay.trigger("close.overlay",
							true);
						$(".checkBoxTree").find(":checked").length == 0 ? $(".rraddtocart").addClass("state-disabled") : $(".rraddtocart").removeClass("state-disabled")
					});
					Target.controller.globalUtils.checkIfCarousal(".component-carousel-1");
					d = 1
				}
			}
		})
	},
	PersoAddToCart : function () {
		var a = "",
		b = $(".perso-horizantol-2 .rraddtocart"),
		d = $(".perso-horizantol-3 .rraddtocart"),
		f = $(".perso-horizantol-2 .checkBoxTree"),
		g = $(".perso-horizantol-3 .checkBoxTree"),
		j = $(".perso-pdpvertical-3 .checkBoxTree"),
		l = $(".perso-pdpvertical-3 .rraddtocart");
		f.find(":checked").length == 0 ? b.addClass("state-disabled").append("<span class='screen-reader-only'> disabled</span>") : b.removeClass("state-disabled");
		g.find(":checked").length == 0 ? d.addClass("state-disabled").append("<span class='screen-reader-only'> disabled</span>") : d.removeClass("state-disabled");
		j.find(":checked").length == 0 ? l.addClass("state-disabled").append("<span class='screen-reader-only'> disabled</span>") : l.removeClass("state-disabled");
		$(".checkBoxTree").click(function () {
			$(".rraddtocart").find("span.screen-reader-only").remove();
			a = "";
			f.find(":checked").length == 0 ? b.addClass("state-disabled").append("<span class='screen-reader-only'> disabled</span>") : b.removeClass("state-disabled");
			g.find(":checked").length == 0 ? d.addClass("state-disabled").append("<span class='screen-reader-only'> disabled</span>") : d.removeClass("state-disabled");
			j.find(":checked").length == 0 ? l.addClass("state-disabled").append("<span class='screen-reader-only'> disabled</span>") : l.removeClass("state-disabled")
		});
		$("#rr_addtocart, #addToCartOverlay").click(function () {
			function o(Q,
				n) {
				var G = 0;
				Q.find(" > li").each(function () {
					var p = $(this).find("input[type='checkbox']:checked");
					$.inArray(p.val(), n) >= 0 && G++
				});
				return G
			}
			var v = 0,
			A = "";
			a = "";
			if ($(this).hasClass("state-disabled") !== true) {
				$(".checkBoxTree").find(":checked").each(function (Q) {
					if (Q > 0)
						a += "&";
					a = a + "partNumber_" + Q + "=" + $(this).val() + "&quantity_" + Q + "=1"
				});
				$.ajaxSetup({
					traditional : true,
					cache : false
				});
				var C = Target.controller.reviewed.cookie.read("esrbResponse");
				if (C != null && C != "")
					a = a + "&esrbResponse=" + C;
				$.ajax({
					url : "/checkout_itemadd?" +
					a + "&fromScript=true&overlay=true&fromRR=Y&errorViewName=ErrorResponse",
					dataType : "json",
					type : "POST",
					success : function (Q) {
						if (typeof Q.errorMessage != "undefined" && Q.errorMessage != "" && Q.errorMessage != null)
							if (Q.errorMessageKey == "ESRBRATING_MATURE_TEXT" || Q.errorMessageKey == "ESRBRATING_FAILURE")
								q(Q);
							else {
								Q = "<div class='errorBlock' style='float:right;margin-top:0px;clear:both;'>" + Q.errorMessage + "</div>";
								$(".errorBlock").remove();
								if ($(".perso-horizantol-2").children().length > 0)
									$(".perso-horizantol-2").after(Q);
								else if ($(".perso-horizantol-3").children().length > 0)
									$(".perso-horizantol-3").after(Q);
								else
									$(".perso-pdpvertical-3").children().length > 0 && $(".perso-pdpvertical-3").after(Q)
							}
						else
							Q.partNumWithOOS != null && typeof Q.partNumWithOOS != "undefined" && Q.partNumWithOOS != "" ? I(Q) : q(Q)
					}
				});
				var q = function (Q) {
					$.overlay.load({
						contentOverride : Q.responseHtml,
						overlayId : Q.overlayId,
						template : Q.template,
						mode : false,
						target : "#rr_addtocart"
					});
					K("", Q.productId)
				},
				I = function (Q) {
					var n = 0;
					partNumberOutOfStockList = Q.partNumWithOOS;
					var G = $("#rr_addtocart").parent().prev(),
					p = "<img class='img-soldout' src='" + $("#oosImagePath").val() + "'  alt='sold out' />",
					r = 0;
					Q = "";
					var z = o(G, partNumberOutOfStockList);
					G.find(" > li").each(function () {
						var u = $(this).find("input[type='checkbox']:checked");
						if (typeof u.val() != "undefined")
							if ($.inArray(u.val(), partNumberOutOfStockList) >= 0) {
								if (v == 0) {
									$(this).find("input[type='checkbox']:checked").replaceWith("");
									$(this).find("a.layer:first").after(p);
									u = "";
									u = $(this).find("a.layer:first > img").attr("alt");
									if (u.indexOf("quick info") > -1)
										u = u.replace("quick info", "");
									$(this).find("a.layer:first > img").attr("alt", u);
									$(this).find("label").remove();
									$(this).find("a.layer:first > img").unwrap().wrap("<p class='pImage' style='display:inline'></p>");
									$(this).find("a").click(function (y) {
										y.preventDefault()
									});
									$(this).find("a").attr("href", "");
									cloneli = $(this).clone();
									$(this).find(".small-product-image").length > 0 ? productimage = cloneli.find(".small-product-image,.product-image")[0].outerHTML : productimage = cloneli.find(".product-image")[0].outerHTML;
									$(this).find(".small-product-price").length > 0 ? productprice = cloneli.find(".small-product-price,.product-price")[0].outerHTML : productprice = cloneli.find(".product-price")[0].outerHTML;
									$(this).find(".small-product-name").length > 0 ? productname = cloneli.find(".small-product-name,.product-name")[0].outerHTML : productname = cloneli.find(".product-name")[0].outerHTML;
									n += 1;
									u = n;
									u = "<div class='RRaddtoCartOverlay'><span class='spandottedImg'>............</span>" + u + " of " + z + "<span class='spandottedImgRight'>............</span></div>";
									A += z > 1 ? "<li>" + u + productimage + productprice + productname + "</li>" : productimage + productprice + productname
								}
							} else
								typeof u.val() != "undefined" && r++
					});
					if (z > 1)
						A = "<div id='ModalCarousel' class='modelCarouselDisp'><ul class='component-carousel-1'>" + A + "</ul></div>";
					G = A;
					if (r > 0)
						Q = "<div class='addinstockitems'><p class='reviewerrorweight'>Add in-stock items to my cart.</p> <a id='addToCartOverlay' class='button rraddtocart layer' title='add items to cart' name='addToCartOverlay' href='#'><span class='buttonText'>add to cart</span></a></div>";
					else
						$(".rraddtocart").addClass("state-disabled");
					var D = $("#reviewSelectionError").val(),
					M = $("#reviewError").val(),
					B = $("#oosError").val(),
					m = $("#oosMsg").val();
					$.overlay.load({
						contentOverride : "<div class='main-content'><h2>" + m + "</h2>" + ("<div class='add2cartnew-leftside add2cartnew-leftside-width'>" + G + ("<div class='quantityOOSMessage'><div class='dispQuantity'>Quantity : <span>1</span></div><div class='OOSError'>" + B + "</div></div>") + "</div>") + ("<div class='add2cartnew-rightside add2cartnew-rightsidealignment'><p>" +
							D + "</p>" + Q + "<div class='addinstockitems'><p class='reviewerrorweight'>" + M + "</p><button title='review items' class='button addtoCart' id='reviewitems' value='1' name='reviewitems' type='submit'><span class='buttonText'>Review Items</span></button></div></div>") + "</div>",
						target : "#rr_addtocart"
					});
					$("#overlay").addClass("OOS-Overlay");
					$("#addToCartOverlay").click(function () {
						$(".checkBoxTree").trigger("click");
						$("#rr_addtocart").trigger("click")
					});
					$("#reviewitems").click(function () {
						$.overlay.currentOverlay.trigger("close.overlay",
							true);
						$(".checkBoxTree").find(":checked").length == 0 ? $(".rraddtocart").addClass("state-disabled") : $(".rraddtocart").removeClass("state-disabled")
					});
					Target.controller.globalUtils.checkIfCarousal(".component-carousel-1");
					v = 1
				},
				K = function (Q, n, G, p, r, z) {
					var D = "",
					M = $("#FormErrors_" + n);
					D = M.html();
					D = Q !== "" ? "<div class='errorBlock'>" + Q + "</div>" : "";
					$(".addtoCartDisabled").removeAttr("disabled");
					M.html(D);
					Q = $("#FormErrors_AddToCart");
					if (typeof Q !== "undefined" && !Q.hasClass("giftCardsError"))
						if (p == "TRUE")
							$("#FormErrors_SpecialItemPrice").append(D);
						else if (r)
							$("#FormErrors_QuickInfoAddToCart").append(D);
						else if (isStorePickUp) {
							$(".searchFiat").append(D);
							$(".qtyEdit").val(z);
							$(".findStoreResult").addClass("fiatHide");
							$(".fiatSearch").removeClass("fiatHide");
							$(".fiatSearch").addClass("fiatShow");
							$("ul.findStore").removeClass("fiatHide");
							$("ul.findStore").addClass("fiatShow");
							$(".storesTabularData").removeClass("fiatShow");
							$(".storesTabularData").addClass("fiatHide");
							$("#replaceEdit").addClass("hidden");
							$("#pickUpInStoreQty").removeClass("hidden");
							$("body").delegate(".qtyEdit ", "keyup", function () {
								$(".qtyhidden").val($(this).val())
							})
						} else {
							var B = $("#FormErrors_AddToCart");
							B.append(D);
							B.html() && B.html().length !== 0 && setTimeout(function () {
								$(document).trigger("updateBuffer.framework");
								B.focus().attr({
									role : "alert",
									tabindex : "-1"
								})
							}, 1E3)
						}
					if (n != G && !isStorePickUp) {
						$("#FormErrors_" + G).append(D);
						if (M !== undefined) {
							z = M.siblings('input[name^="quantity_"]');
							if (z !== undefined && z.length) {
								n = z.attr("name").split("_")[1];
								$("#collection").length && z.val() === "0" && $("#catEntryId_" +
									n).remove()
							}
						}
					}
				}
			}
		});
		$(".perso_vertical_6_1").ready(function () {
			var o = $(".perso_vertical_6_1 ul li");
			o.eq(0).addClass("lastRowItem");
			o.eq(1).addClass("lastRowItem");
			o.filter(":odd").addClass("lastlistItem")
		})
	},
	DvmAdInit : function () {
		var a = document.createElement("script");
		a.async = true;
		a.type = "text/javascript";
		a.src = ("https:" == document.location.protocol ? "https:" : "http:") + "//www.googletagservices.com/tag/js/gpt.js";
		var b = document.getElementsByTagName("script")[0];
		b.parentNode.insertBefore(a, b);
		console.log("Dvm Ad Init ::",
			a.src)
	},
	getObjSize : function (a) {
		var b = 0,
		d;
		if (typeof a == "string")
			b = a.length;
		else
			for (d in a)
				a.hasOwnProperty(d) && b++;
		return b
	},
	DvmAdDisplay : function (a) {
		var b = this,
		d,
		f,
		g,
		j,
		l;
		try {
			b.getObjSize(a) != 0 && googletag.cmd.push(function () {
				$.each(dfp_placements.dfp_adUnit, function (v, A) {
					d = $.trim(A.dfp_placementID);
					f = $.trim(A.dfp_category);
					g = A.dfp_dimension;
					if (b.getObjSize(d) != 0 && b.getObjSize(f) != 0 && b.getObjSize(g) != 0) {
						j = googletag.defineSlot(f, g, d);
						j.addService(googletag.pubads());
						b.getObjSize(A.dfp_adLevelTargetVal) !=
						0 && $.each(A.dfp_adLevelTargetVal, function (C, q) {
							$.each(q, function (I, K) {
								b.getObjSize(I) != 0 && j.setTargeting(I, K)
							})
						});
						j.setCollapseEmptyDiv(true)
					}
				});
				googletag.pubads().addEventListener("slotRenderEnded", function () {
					$("iframe").attr("title", "3rd party advertisement");
					$("#dvm_gpt-category_page-site_merch_promo_global_slot iframe").attr("title", "Target Promotions");
					$("#dvm_gpt-category_page-site_merch_promo_banner iframe").attr("title", "Target Promotions");
					$("iframe").attr("role", "presentation")
				});
				googletag.pubads().enableSingleRequest();
				googletag.pubads().enableAsyncRendering();
				l = dfp_placements.dfp_ppid;
				l != "-1002" && b.getObjSize(l) != 0 && googletag.pubads().setPublisherProvidedId(l);
				googletag.enableServices();
				b.getObjSize(a.dfp_pageLevelTargetVal) != 0 && $.each(a.dfp_pageLevelTargetVal, function (v, A) {
					$.each(A, function (C, q) {
						if (typeof q.s_vi === "undefined" || q.s_vi == "")
							q.s_vi = gpt_siteCatalystId != "" ? gpt_siteCatalystId : "";
						b.getObjSize(C) != 0 && googletag.pubads().setTargeting(C, q)
					})
				});
				$.each(dfp_placements.dfp_adUnit, function (v, A) {
					d = $.trim(A.dfp_placementID);
					googletag.display(d)
				})
			})
		} catch (o) {
			console.log(o.message)
		}
	},
	validateReferrer : function () {
		if (document.referrer && document.referrer != "") {
			ref = document.referrer;
			ref_hostname = ref.match(/:\/\/(.[^/] + ) / )[1];
			ostVal = ref_hostname.indexOf("target.com") > -1 ? false : true
		} else
			ostVal = false;
		return ostVal
	},
	DVMAdDisplayAfterLazy : function (a) {
		setTimeout(function () {
			$.each(a.dfp_adUnit, function (b, d) {
				dfpPlacementId = $.trim(d.dfp_placementID);
				contentLength = $("#" + dfpPlacementId).html().trim().length;
				!contentLength > 0 && googletag.display(dfpPlacementId)
			})
		},
			300);
		msnryFunction(3)
	}
});
